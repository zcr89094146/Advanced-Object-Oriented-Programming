public class ValidateLength implements Validation{
    @Override
    public String validate(String input) {
        //Check if the input is empty

        if(input == null){
            System.out.println("Empty input!");
            return "Empty input!";
        }

        //Checks if the input length is less than the specified expression length

        if(input.length() < equation_length){
            System.out.println("Your input are too less.");
            return "Your input are too less.";
        }else if(input.length() > equation_length){
            System.out.println("Your input are too long.");
            return "Your input are too long.";
        }
        return null;
    }
}
