import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.FileNotFoundException;

class NumberleModelTest {
    private NumberleModel model;
    @BeforeEach
    void setUp() {
        model = new NumberleModel();
    }

    @Test
    void testInitialize() throws FileNotFoundException {
        // Test that the initialisation method correctly sets the initial state of the model
        model.initialize();
        assertNotNull(model.getTargetEquation());
        assertEquals(7, model.getCurrentGuess().length());
        assertEquals(NumberleModel.MAX_ATTEMPTS, model.getRemainingAttempts());
        assertFalse(model.isGameOver());
    }

    @Test
    void testProcessInput_CorrectInput() throws FileNotFoundException {
        // Test inputs that are valid and within the rules of the game
        model.initialize();
        assertTrue(model.processInput("3+4-1=6")); // Enter a valid equation
        assertFalse(model.isGameWon());
        assertFalse(model.isGameOver());
    }

    @Test
    void testProcessInput_InvalidInput() throws FileNotFoundException {
        // Test for inputs that are invalid (e.g., contain characters other than non-numeric or operator characters)
        model.initialize();
        assertFalse(model.processInput("abc123=")); // Invalid character input
        assertFalse(model.isGameWon());
        assertFalse(model.isGameOver());
    }
}
