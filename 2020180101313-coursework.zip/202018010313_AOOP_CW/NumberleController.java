import java.io.FileNotFoundException;

// NumberleController.java
public class NumberleController {
    private INumberleModel model;
    private NumberleView view;
    private boolean hasValidGuess;

    //Constructor
    public NumberleController(INumberleModel model) {

        this.model = model;
        this.hasValidGuess = false;
    }

    //Set View Objects
    public void setView(NumberleView view) {
        this.view = view;
        this.model.setObserver(view);
    }

    //Process user input
    public boolean processInput(String input) {

        return model.processInput(input);
    }

    //Determine if the game is over

    public boolean isGameOver() {

        return model.isGameOver();
    }


    //Determine if the game is won or not
   public boolean isGameWon() {

        return model.isGameWon();
    }


    //Get target word
   public String getTargetWord() {

        return model.getTargetEquation();
    }

    //get currentGuess
   public StringBuilder getCurrentGuess() {

        return model.getCurrentGuess();
    }

    //Get remaining attempts
    public int getRemainingAttempts() {

        return model.getRemainingAttempts();
    }

    //Starting a new game may throw a file not found exception
    public void startNewGame() throws FileNotFoundException {
        model.startNewGame();
    }

    public boolean hasValidGuess() {
        return hasValidGuess;
    }

    public void setHasValidGuess(boolean hasValidGuess) {

        this.hasValidGuess = hasValidGuess;
    }
    public void handleRestartGame() {
        try {
            startNewGame();
            // disableReplayButton
            view.disableReplayButton();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }

}