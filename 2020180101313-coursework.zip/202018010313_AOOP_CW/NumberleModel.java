// NumberleModel.java
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Observer;
import java.util.Random;
import java.util.Observable;
import java.util.Scanner;

public class NumberleModel extends Observable implements INumberleModel {
    private String targetEquation;
    private StringBuilder currentGuess;
    private int remainingAttempts;
    private boolean gameWon;
    private Validation[] validators = {
            new ValidateLength(), new ValidateCharacter(),
            new ValidateFormate(), new ValidateMathmatic()
    };

    public boolean isFirstGuess() {
        return remainingAttempts == 6;
    }


    private String errorMessage = null;
    private int[] guessSiduation = new int[7];

    public void setObserver(Observer observer){

        this.addObserver(observer);
    }
    public void clearErrorMessage(){

        this.errorMessage = null;
    }
    public String getErrorMessage(){

        return errorMessage;
    }

   // Initialise the game, choosing a random expression from the file as the target

    @Override
    public void initialize() throws FileNotFoundException {

        // read the file and randomly choose one equation.
        try {
            InputStream inputStream = new FileInputStream("equations.txt");
            Scanner file = new Scanner(inputStream, "utf-8");

            Random rand = new Random();
            //Generate a random number to determine the number of lines to read from the file
            int lineNum = rand.nextInt(108);

            //Reads the file line by line until it reaches a randomly selected number of lines
            for(int i=0; i<lineNum; i++) {
                targetEquation = file.nextLine();
            }

        } catch (FileNotFoundException e){
            e.printStackTrace();
            //Prints an exception message if the file is not found
        }


        System.out.println(targetEquation);

        currentGuess = new StringBuilder("       ");//Initialise the current guess to a space
        remainingAttempts = MAX_ATTEMPTS;//Initialise the number of remaining attempts
        gameWon = false;//Initialise game win status to false
        guessSiduation[0] = -1;//Initialise the array of guessing situations
        setChanged();
        notifyObservers();//Notify the observer that the game state has changed

    }


    //Processing user input
    @Override
    public boolean processInput(String input) {

        input = input.replaceAll("\\s", "");// Remove spaces from input

        //Validation Input Format
        for(int i=0; i<validators.length; i++){
            String val = validators[i].validate(input);
            if(val != null){
                errorMessage = val;
                setChanged();
                notifyObservers();
                return false;
            }
        }

        //Check that the position and content of each character is correct
        for(int i=0; i<input.length(); i++){
            if(input.charAt(i) == targetEquation.charAt(i)){
                guessSiduation[i] = 0;//Correct character position
                System.out.println(input.charAt(i) + ": is in the Right place");
            }else if(targetEquation.contains(String.valueOf(input.charAt(i)))){
                guessSiduation[i] = 1;//Characters are present but not in the correct position
                System.out.println(input.charAt(i) + ": is in the Wrong place");
            }else{
                guessSiduation[i] = 2;//character does not exist
                System.out.println(input.charAt(i) + ": not exist.");
            }
        }

        //Determine if the target expression is guessed
        if(input.equals(targetEquation)){
            this.gameWon = true;
        }

        //For each input processed, the number of remaining attempts is reduced by one
        remainingAttempts--;
        setChanged();
        notifyObservers();
        return true;
    }

    //Determine if the game is over
    @Override
    public boolean isGameOver() {
        return remainingAttempts <= 0 || gameWon;
    }

    //Determine if the game is won or not
    @Override
    public boolean isGameWon() {
        return gameWon;
    }

    // Get the array of guessing scenarios
    public int[] getGussSiduation(){
        return guessSiduation;
    }

    //Get target expression
    @Override
    public String getTargetEquation() {
        return targetEquation;
    }

    //getCurrentGuess
    @Override
    public StringBuilder getCurrentGuess() {
        return currentGuess;
    }

    //getRemainingAttempts
    @Override
    public int getRemainingAttempts() {
        return remainingAttempts;
    }

    //startNewGame
    @Override
    public void startNewGame() throws FileNotFoundException {
        initialize();
    }

}
