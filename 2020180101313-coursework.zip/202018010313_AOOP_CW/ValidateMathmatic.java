import java.util.Stack;

public class ValidateMathmatic implements Validation {


    @Override
    public String validate(String expression) {
        //Split the expression into left and right parts by the equal sign
        String[] expressions = expression.split("=");
        // Calculating the expression on the left gives the result
        int result1 = doCuculation(expressions[0]);
        //Calculating the expression on the right-hand side yields the result
        int result2 = doCuculation(expressions[1]);
        //Check that the results are equal on both sides
        if(result1 != result2){
            System.out.println("It's not a equation!");
            return "It's not a equation!";
        }

        return null;
    }

    //invert the stack (computing)
    private static Stack<Integer> reverseStack(Stack<Integer> stack) {
        if (stack.isEmpty()) {return stack;}
        Stack<Integer> tempStack = new Stack<>();
        while (!stack.isEmpty()) {tempStack.push(stack.pop());}
        return tempStack;
    }

    private static Stack<Character> reverseStackString(Stack<Character> stack) {
        if (stack.isEmpty()) {return stack;}
        Stack<Character> tempStack = new Stack<>();
        while (!stack.isEmpty()) {tempStack.push(stack.pop());}
        return tempStack;
    }

    //Perform expression calculations
    private static int doCuculation(String expression){
        Stack<Integer> numbers = new Stack<>();
        Stack<Character> operators = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);
            //If numeric, parses consecutive numeric characters and presses them into the numeric stack
            if (Character.isDigit(c)) {
                StringBuilder numStr = new StringBuilder();
                numStr.append(c);
                while (i + 1 < expression.length() && Character.isDigit(expression.charAt(i + 1))) {
                    numStr.append(expression.charAt(i + 1));
                    i++;
                }
                numbers.push(Integer.parseInt(numStr.toString()));
            } else if (c == '+' || c == '-') {
                //If it's a plus or minus sign, puts the operator on the stack or performs the calculation according to priority
                while (!operators.isEmpty() && (operators.peek() == '*' || operators.peek() == '/')) {
                    char op = operators.pop();
                    int num2 = numbers.pop();
                    int num1 = numbers.pop();
                    numbers.push(applyOperation(num1, num2, op));
                }
                operators.push(c);
                //If it's a multiplication or division sign, it goes directly to the stack
            } else if (c == '*' || c == '/') {
                operators.push(c);
            }
        }

        //Handling the remaining operators and operands
        if (!operators.isEmpty() && (operators.peek() == '*' || operators.peek() == '/')) {
            char op = operators.pop();
            int num2 = numbers.pop();
            int num1 = numbers.pop();
            numbers.push(applyOperation(num1, num2, op));
        }
        //Reverse the stack to ensure that calculations are performed in positive order

        numbers = reverseStack(numbers);
        operators = reverseStackString(operators);

        //Perform the remaining calculations
        while (!operators.isEmpty()) {
            char op = operators.pop();
            int num1 = numbers.pop();
            int num2 = numbers.pop();
            numbers.push(applyOperation(num1, num2, op));
        }

        //Returns the final result
        int result = numbers.pop();
//        System.out.println(result);

        return result;
    }

    private static int applyOperation(int num1, int num2, char op) {
        switch (op) {
            case '+':
                return num1 + num2;
            case '-':
                return num1 - num2;
            case '*':
                return num1 * num2;
            case '/':
                return num1 / num2;
            default:
                return 0;
        }
    }
}
