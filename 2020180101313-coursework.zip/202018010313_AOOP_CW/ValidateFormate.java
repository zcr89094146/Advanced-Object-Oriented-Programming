public class ValidateFormate implements Validation{
    private boolean preCharacter; // if preChracter is 1 means it's number otherwise is operator.

    //Used to distinguish whether a character is a number or an operator
    private boolean charDistinguish(String c){
        assert c.length() == 1;
        if(c.matches("[0-9]")){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public String validate(String input) {
        // Check if the input contains "="
        if(!input.contains("=")) return "Lack of '='";
        // Returns an error message indicating that "=" is missing
        //Initialise preCharacter, setting it according to whether the first character is a number or an operator
        preCharacter = charDistinguish(String.valueOf(input.charAt(0)));
        //Returns an error message indicating that the first character must be a number
        if(!preCharacter){
            System.out.println("The First character must be a number!");
            return "The First character must be a number!";
        }
        //Iterate through the input string, checking that the position and type of each character matches the requirements
        for(int i=1; i<equation_length; i++){
            boolean currentCharacter = charDistinguish(String.valueOf(input.charAt(i)));
            //If the previous character is an operator and the current character is also an operator, an error message is returned
//            System.out.println(currentCharacter);
            if(!preCharacter && !currentCharacter){
                System.out.println("The place after Operator can not be Operator!");
                return "The place after Operator can not be Operator!";
            }
            //Update the type of the previous character to the type of the current character
            preCharacter = currentCharacter;
        }
        //Returns an error message indicating that the operator cannot appear at the end of the expression
        if(!preCharacter){
            System.out.println("The Last character can not be a operator");
            return "The place after Operator can not be Operator!";
        }
        return null;
    }
}
