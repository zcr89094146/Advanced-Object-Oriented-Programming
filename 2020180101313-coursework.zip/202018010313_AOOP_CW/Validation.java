
public interface Validation {
    final int equation_length = 7;
    public String validate(String input);


}
