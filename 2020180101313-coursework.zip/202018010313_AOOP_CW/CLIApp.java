import java.io.FileNotFoundException;
import java.util.Scanner;

public class CLIApp {
    public static void main(String[] args) throws FileNotFoundException {
        //Create a Scanner object to read user input from the console.
        Scanner user_input = new Scanner(System.in);

// Get the model instance from the GUI version
        INumberleModel model = GUIApp.getModelInstance();

        System.out.println(model.getRemainingAttempts());

        model.startNewGame();
        //When the game is not finished, loop through the following steps
        while(!model.isGameOver()){
            System.out.println("enter the game");
            String str = "";
            //Loop to get user input until it matches
            do {
                str = user_input.nextLine();
            }while(!model.processInput(str));
            // Determine if the game is over
            if(model.isGameOver()){
                if(model.isGameWon()){
                    System.out.println("You are win!");
                }else{
                    System.out.println("You are lose!");
                }
                break;
            }
            System.out.println("You have remain: " + model.getRemainingAttempts() + " chances.");
        }
    }
}
