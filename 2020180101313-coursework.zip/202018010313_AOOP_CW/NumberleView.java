import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.Observer;
import java.util.Observable;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

//Game interface view class, inherits from JFrame and implements the Observer interface,
// used to display the game interface and handle game state updates.
public class NumberleView extends JFrame implements Observer {
//    private JFrame jf;

    // Maximum number of guesses
    private static final int maxGuess = 6;
    // Expression length
    private static final int equationLength = 7;
    // Grid for displaying guesses
    private JLabel[][] guessGrid;
    // Guess results display panel
    private JPanel gridPanel;
    private JPanel buttonPanel;

    private StringBuilder currentGuess = new StringBuilder("");

    private NumberleController controller;
    private JButton rePlayButton;



    // Border Styles
    private Border emptyBorder = new EmptyBorder(10, 5, 10, 5);
    private Border grayBorder = BorderFactory.createLineBorder(Color.GRAY, 5);
    private Border yellowBorder = BorderFactory.createLineBorder(Color.yellow, 5);
    private Border greenBorder = BorderFactory.createLineBorder(Color.green, 5);
    //Font Style
    private Font customFont = new Font("Arial", Font.BOLD, 20);


    //Constructor to initialise the interface and set up the controller
    public NumberleView(NumberleController controller) {
        super("Numberle Game");
        this.controller = controller;
        initializeFrame();
        this.controller.setView(this);

    }


    //Initialising the main interface framework
    public void initializeFrame() {

        //Setting the shutdown operation
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //Setting the layout as a boundary layout
        setLayout(new BorderLayout());
        //Initialise the guess results display panel
        initializeGridPanel();
        //Initialising the button panel
        initializeButtonPanel();
        //Automatic resizing
        pack();
        //Setting the window to be centred
        setLocationRelativeTo(null);
        //Setting Visible
        setVisible(true);
        // Disable resizing
        this.setResizable(false);
    }


    //Initialise the guess results display panel
    //Create and style the guess results label and its border and add it to the panel. A grid layout is used here
    public void initializeGridPanel() {

        guessGrid = new JLabel[maxGuess][equationLength];
        gridPanel = new JPanel(new GridLayout(maxGuess, equationLength));
        JButton rePlayButton = new JButton("Replay");
        rePlayButton.setFont(this.customFont);
        rePlayButton.setEnabled(false); // Initially disable the "Replay" button.
        rePlayButton.addActionListener(e -> {
            // Replay button click logic
        });

        gridPanel.setLayout(new GridLayout(6, 7));
        Border panelBorder = new EmptyBorder(10, 130, 10, 130);
        gridPanel.setBorder(panelBorder);

        for (int i = 0; i < maxGuess; i++) {
            for (int j = 0; j < equationLength; j++) {
                JLabel label = new JLabel();


                Border border = BorderFactory.createCompoundBorder(emptyBorder, grayBorder);
                JPanel borderPanel = new JPanel();
                borderPanel.setBorder(emptyBorder);
                label.setBorder(grayBorder);
                borderPanel.add(label);
//                Font font = label.getFont();
                label.setFont(this.customFont);
                label.setHorizontalAlignment(JLabel.CENTER);
                Dimension labelDim = new Dimension(70, 70);
                label.setPreferredSize(labelDim);
                label.setMinimumSize(labelDim);
                label.setMaximumSize(labelDim);
                guessGrid[i][j] = label;
                gridPanel.add(borderPanel);
            }
        }
        add(gridPanel, BorderLayout.CENTER);

    }

    //Initialising the button panel
    //Create number buttons, delete buttons and submit buttons and add them to the panel
    public void initializeButtonPanel() {
        buttonPanel = new JPanel(new GridLayout(2, 5, 5, 5));

        String[] buttons = {
                "1", "2", "3", "4", "5", "6", "7",
                "8", "9", "0", "+", "-", "*", "/", "="
        };

        for (String buttonText : buttons) {
            JButton button = new JButton(buttonText);
            button.setFont(this.customFont);
            button.setBorder(emptyBorder);
            button.addActionListener(e -> {
                if (currentGuess.length() < equationLength) {
                    this.currentGuess.append(buttonText);
                    assert buttonText.length() <= equationLength;
                    guessGrid[maxGuess - controller.getRemainingAttempts()][currentGuess.length() - 1].setText(buttonText);
                }
            });
            buttonPanel.add(button);
        }

        // Delete button click event handling logic
        JButton deleteButton = new JButton("Delete");
        deleteButton.setFont(this.customFont);
        deleteButton.addActionListener(e -> {
            if (currentGuess.length() != 0) {
                guessGrid[maxGuess - controller.getRemainingAttempts()][currentGuess.length() - 1].setText(" ");
                currentGuess.deleteCharAt(currentGuess.length() - 1);
            }
        });

        // button click event handling logic
        JButton submitButton = new JButton("Enter");
        submitButton.setFont(this.customFont);
        submitButton.addActionListener(e -> {
            if (controller.processInput(currentGuess.toString())) {
                currentGuess.setLength(0);
            }
        });

        //  button click event handling logic
        rePlayButton = new JButton("Replay");
        rePlayButton.setFont(this.customFont);
        rePlayButton.setEnabled(false);
        rePlayButton.addActionListener(e -> {
            controller.handleRestartGame();
            currentGuess.setLength(0);
            try {
                controller.startNewGame();
                controller.setHasValidGuess(false); // reset
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
            resetButtonPanel();
            initializeGridPanel();
        });

        // Adding a Button to the Button Panel
        buttonPanel.add(deleteButton);
        buttonPanel.add(submitButton);
        buttonPanel.add(rePlayButton);


        this.add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    //update method for receiving notification of game model status updates
    @Override
    public void update(Observable o, Object arg) {
        if (o instanceof NumberleModel) {
            NumberleModel model = (NumberleModel) o;//Forced Type Conversion to NumberleModel
            if (model.getRemainingAttempts() < 6 && !controller.hasValidGuess()) {
                rePlayButton.setEnabled(true);
            }
            String error = model.getErrorMessage();
            if (error != null) {
                error = "<html><font size='5'>" + error + "</font></html>";
                JOptionPane.showMessageDialog(null, error, "Invalid Input", JOptionPane.ERROR_MESSAGE);
                model.clearErrorMessage();
                return;
            }

            if (model.getGussSiduation()[0] == -1) {
                guessGrid[0][0].setText(" ");
                guessGrid[0][0].setBorder(grayBorder);
                guessGrid[0][0].setOpaque(false);
                return;
            }
            //Updated guesses show

            for (int i = 0; i < equationLength; i++) {
                if (model.getGussSiduation()[i] == 0) {
                    guessGrid[maxGuess - model.getRemainingAttempts() - 1][i].setBackground(Color.green);
                    guessGrid[maxGuess - model.getRemainingAttempts() - 1][i].setBorder(greenBorder);
                    searchButton(guessGrid[maxGuess - model.getRemainingAttempts() - 1][i].getText()).setBackground(Color.green);
                } else if (model.getGussSiduation()[i] == 1) {
                    guessGrid[maxGuess - model.getRemainingAttempts() - 1][i].setBackground(Color.yellow);
                    guessGrid[maxGuess - model.getRemainingAttempts() - 1][i].setBorder(yellowBorder);
                    if (searchButton(guessGrid[maxGuess - model.getRemainingAttempts() - 1][i].getText()).getBackground() != Color.green) {
                        searchButton(guessGrid[maxGuess - model.getRemainingAttempts() - 1][i].getText()).setBackground(Color.yellow);
                    }
                } else {
                    guessGrid[maxGuess - model.getRemainingAttempts() - 1][i].setBackground(Color.gray);
                    guessGrid[maxGuess - model.getRemainingAttempts() - 1][i].setBorder(grayBorder);
                    searchButton(guessGrid[maxGuess - model.getRemainingAttempts() - 1][i].getText()).setBackground(Color.gray);
                }
                guessGrid[maxGuess - model.getRemainingAttempts() - 1][i].setOpaque(true);
            }


            //Output current guess and remaining attempts to the console
            System.out.println("Current guess: " + model.getCurrentGuess());
            System.out.println("Remaining attempts: " + model.getRemainingAttempts());
            //Determine whether the game is over or not, and display the corresponding prompt dialogue box
            if (model.isGameOver()) {
                if (model.isGameWon()) {
                    JOptionPane.showMessageDialog(null, "<html><font size='5'>Congratulations, you won the game!</font></html>",
                            "Game Result", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "<html><font size='5'>Sorry! You run out of chances!</font></html>",
                            "Game Result", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    //Find buttons by button text
    private JButton searchButton(String buttonName) {
        for (Component button : buttonPanel.getComponents()) {
            if (((JButton) button).getText().contains(buttonName)) {
                return (JButton) button;
            }
        }
        return null;
    }
   // Reset the button panel to set the button background colour to the default colour
    private void resetButtonPanel() {
        for(Component button: buttonPanel.getComponents()){
            if(button instanceof JButton) {
                JButton numButton = (JButton) button;
                numButton.setBackground(null); // set null
            }
        }
    }
    // Disable Replay Button

    public void disableReplayButton() {
        rePlayButton.setEnabled(false);
    }
}