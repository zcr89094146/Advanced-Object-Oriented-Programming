public class ValidateCharacter implements Validation{

    @Override
    //Checks that the input contains only numbers and operators
    public String validate(String input) {
        if(!input.matches("[0-9+\\-*/=]+")){
            System.out.println("Your input only can be number or operator.");
            return "Your input only can be number or operator.";
        }
        return null;
        // Returns null to indicate that the input is valid
    }
}
